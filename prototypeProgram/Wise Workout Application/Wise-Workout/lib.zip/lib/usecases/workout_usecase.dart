class WorkoutUseCase {
  Future<void> createWorkoutLogEntry({required String workoutId, required String note}) async {}
  Future<void> viewWorkoutLog() async {}
  Future<void> viewDailyWorkout() async {}
}

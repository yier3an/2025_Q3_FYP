import 'package:flutter/material.dart';

class PlanPage extends StatelessWidget {
  const PlanPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Manage Plan')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Your Current Plan', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Card(
            child: ListTile(
              leading: const Icon(Icons.person_outline),
              title: const Text('Free User'),
              subtitle: const Text('Basic workouts, community feed'),
            ),
          ),
          const SizedBox(height: 16),
          const Text('Upgrade Options', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Card(
            child: ListTile(
              leading: const Icon(Icons.workspace_premium),
              title: const Text('Premium'),
              subtitle: const Text('Advanced analytics, groups & tournaments'),
              trailing: FilledButton(
                onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Upgraded to Premium (mock)')),
                ),
                child: const Text('Upgrade'),
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text('Billing History (mock)'),
          const ListTile(title: Text('— No charges yet —')),
        ],
      ),
    );
  }
}

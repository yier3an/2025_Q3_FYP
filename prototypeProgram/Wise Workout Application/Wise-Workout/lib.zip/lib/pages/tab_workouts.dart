import 'package:flutter/material.dart';
import '../mock_data.dart';
import '../services/auth_service_mock.dart';
import '../theme.dart';
import '../widgets_paywall.dart';
import 'shared_header.dart';
import 'workout_edit_page.dart';

class WorkoutsTabPage extends StatefulWidget {
  final bool isPremium;
  const WorkoutsTabPage({super.key, this.isPremium = false});
  @override
  State<WorkoutsTabPage> createState() => _WorkoutsTabPageState();
}

class _WorkoutsTabPageState extends State<WorkoutsTabPage>
    with SingleTickerProviderStateMixin {
  late final TabController _tc;

  @override
  void initState() {
    super.initState();
    _tc = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const SharedHeader(),
      body: Column(
        children: [
          const SizedBox(height: 8),
          _PillTabBar(controller: _tc, tabs: const [
            Tab(text: 'Workouts'),
            Tab(text: 'Your Analytics'),
            Tab(text: 'Logbook'),
            Tab(text: 'Fitness Trainer'),
          ]),
          const SizedBox(height: 8),
          Expanded(
            child: TabBarView(
              controller: _tc,
              children: [
                _WorkoutsView(),
                AnalyticsView(isPremium: widget.isPremium),
                _LogbookView(),
                _TrainerView(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PillTabBar extends StatelessWidget {
  final TabController controller;
  final List<Widget> tabs;
  const _PillTabBar({required this.controller, required this.tabs, super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemBuilder: (_, i) => _pill(tabs[i], i == controller.index),
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemCount: tabs.length,
      ),
    );
  }

  Widget _pill(Widget w, bool active) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: active ? Colors.black : AppTheme.purpleLight,
        borderRadius: BorderRadius.circular(22),
      ),
      alignment: Alignment.center,
      child: DefaultTextStyle(
        style: TextStyle(color: active ? Colors.white : Colors.black),
        child: w,
      ),
    );
  }
}

// --- Premium analytics with overlay for Free users ---
class AnalyticsView extends StatelessWidget {
  final bool isPremium;
  const AnalyticsView({super.key, required this.isPremium});
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        ListView(
          padding: const EdgeInsets.all(12),
          children: [
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: const [
                _MetricCard(
                    title: 'Calories Burned', value: '512k', subtitle: '+8% of target'),
                _MetricCard(title: 'KM ran', value: '2M', subtitle: '+8% of target'),
              ],
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: AppTheme.purpleLight,
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('Pushups Completed',
                      style: TextStyle(fontWeight: FontWeight.w600)),
                  SizedBox(height: 80, child: Placeholder()),
                ],
              ),
            ),
            const SizedBox(height: 12),
            const Text('Profile Analytics',
                style: TextStyle(fontWeight: FontWeight.bold)),
            const ListTile(title: Text('Followers count'), trailing: Text('855')),
            const ListTile(title: Text('Followed count'), trailing: Text('723')),
            const ListTile(title: Text('Longest Streak'), trailing: Text('25 Days')),
          ],
        ),
        if (!isPremium)
        Positioned.fill(
    child: IgnorePointer(
    ignoring: false, // block interactions
    child: Container(
    alignment: Alignment.center,
    color: Colors.white.withOpacity(0.70),
    child: const PremiumWall(
    title: 'Premium Analytics',
    message: 'Unlock performance graphs and advanced analytics',
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// --- Workouts (Free) + actions that mimic WBS ---
class _WorkoutsView extends StatefulWidget {
  const _WorkoutsView();
  @override
  State<_WorkoutsView> createState() => _WorkoutsViewState();
}

class _WorkoutsViewState extends State<_WorkoutsView> {
  @override
  Widget build(BuildContext context) {
    final ex = MockData.exercises;
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Row(
          children: [
            FilledButton.icon(
              onPressed: () async {
                // mimic wearable sync: mark first 2 as progressed
                if (ex.isNotEmpty) {
                  ex[0] = Exercise(ex[0].title, ex[0].totalText, 'Completed: 20', edited: true);
                }
                if (ex.length > 1) {
                  ex[1] = Exercise(ex[1].title, ex[1].totalText, 'Completed: 1.1 KM', edited: true);
                }
                setState(() {});
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Synced from wearable (mock)')),
                );
              },
              icon: const Icon(Icons.sync),
              label: const Text('Sync from wearable'),
            ),
            const SizedBox(width: 8),
            OutlinedButton.icon(
              onPressed: () async {
                final changed = await Navigator.push(
                    context, MaterialPageRoute(builder: (_) => const WorkoutEditPage()));
                if (changed == true) setState(() {});
              },
              icon: const Icon(Icons.add),
              label: const Text('New workout'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        ...List.generate(ex.length, (i) {
          final e = ex[i];
          return Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.fitness_center)),
              title: Text(e.title, style: TextStyle(fontWeight: e.edited ? FontWeight.bold : FontWeight.normal)),
              subtitle: Text('${e.totalText}\n${e.completedText}'),
              isThreeLine: true,
              trailing: TextButton(
                child: const Text('Edit'),
                onPressed: () async {
                  final changed = await Navigator.push(
                      context, MaterialPageRoute(builder: (_) => WorkoutEditPage(index: i)));
                  if (changed == true) setState(() {});
                },
              ),
            ),
          );
        }),
        const SizedBox(height: 12),
        const Text('Tutorial Videos', style: TextStyle(fontWeight: FontWeight.bold)),
        Card(child: ListTile(leading: const Icon(Icons.play_circle_outline), title: const Text('Proper Pushup Form'), trailing: const Icon(Icons.chevron_right))),
        Card(child: ListTile(leading: const Icon(Icons.play_circle_outline), title: const Text('Stretching Basics'), trailing: const Icon(Icons.chevron_right))),
      ],
    );
  }
}

class _LogbookView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: const [
        ListTile(
            title: Text('December 10 2025'),
            subtitle: Text('Day 13 of gym training\nPB: 100KG Bench 5 reps')),
        ListTile(
            title: Text('December 02 2025'),
            subtitle: Text('Day 5 of gym training\nPB: 90KG Bench 2 reps')),
      ],
    );
  }
}

class _TrainerView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(mainAxisSize: MainAxisSize.min, children: const [
        Icon(Icons.school_outlined, size: 56),
        SizedBox(height: 8),
        Text('Trainer marketplace (placeholder)'),
      ]),
    );
  }
}

class _MetricCard extends StatelessWidget {
  final String title, value, subtitle;
  const _MetricCard({required this.title, required this.value, required this.subtitle, super.key});
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 180,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title),
              const SizedBox(height: 6),
              Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text(subtitle, style: const TextStyle(color: Colors.green)),
            ],
          ),
        ),
      ),
    );
  }
}

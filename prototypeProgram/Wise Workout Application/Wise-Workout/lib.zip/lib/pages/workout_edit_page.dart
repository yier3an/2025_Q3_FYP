import 'package:flutter/material.dart';
import '../mock_data.dart';

class WorkoutEditPage extends StatefulWidget {
  final int? index; // null => create
  const WorkoutEditPage({super.key, this.index});

  @override
  State<WorkoutEditPage> createState() => _WorkoutEditPageState();
}

class _WorkoutEditPageState extends State<WorkoutEditPage> {
  late final TextEditingController title;
  late final TextEditingController total;
  late final TextEditingController completed;

  @override
  void initState() {
    super.initState();
    final ex = (widget.index != null) ? MockData.exercises[widget.index!] : null;
    title = TextEditingController(text: ex?.title ?? '');
    total = TextEditingController(text: ex?.totalText ?? '');
    completed = TextEditingController(text: ex?.completedText ?? '');
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.index != null;
    return Scaffold(
      appBar: AppBar(title: Text(isEdit ? 'Edit Workout' : 'New Workout')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: title, decoration: const InputDecoration(labelText: 'Title')),
            TextField(controller: total, decoration: const InputDecoration(labelText: 'Total text')),
            TextField(controller: completed, decoration: const InputDecoration(labelText: 'Completed text')),
            const Spacer(),
            FilledButton(
              onPressed: () {
                MockData.upsertExercise(
                  index: widget.index,
                  ex: Exercise(title.text.trim(), total.text.trim(), completed.text.trim(), edited: true),
                );
                Navigator.pop(context, true);
              },
              child: Text(isEdit ? 'Save' : 'Create'),
            )
          ],
        ),
      ),
    );
  }
}

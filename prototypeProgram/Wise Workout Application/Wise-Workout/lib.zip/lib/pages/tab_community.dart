import 'package:flutter/material.dart';
import 'shared_header.dart';
import '../services/auth_service_mock.dart';
import '../widgets_paywall.dart';

class CommunityTabPage extends StatefulWidget {
  final bool isPremium;
  const CommunityTabPage({super.key, this.isPremium = false});
  @override
  State<CommunityTabPage> createState() => _CommunityTabPageState();
}

class _CommunityTabPageState extends State<CommunityTabPage>
    with SingleTickerProviderStateMixin {
  final Set<int> _joinedGroupIds = {};
  final Set<int> _joinedChallengeIds = {};
  late final TabController _tc;
  @override
  void initState() {
    super.initState();
    _tc = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const SharedHeader(),
      body: Column(
        children: [
          const SizedBox(height: 8),
          _PillTabs(controller: _tc, tabs: const [
            Tab(text: 'Active'),
            Tab(text: 'Challenges'),
            Tab(text: 'Groups'),
          ]),
          const SizedBox(height: 8),
          Expanded(
            child: TabBarView(
              controller: _tc,
              children: const [_ActiveView(), _ChallengesView(), _GroupsView()],
            ),
          ),
        ],
      ),
    );
  }
}

class _PillTabs extends StatelessWidget {
  final TabController controller;
  final List<Widget> tabs;
  const _PillTabs({required this.controller, required this.tabs});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemBuilder: (_, i) => _pill(tabs[i], i == controller.index),
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemCount: tabs.length,
      ),
    );
  }

  Widget _pill(Widget w, bool active) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: active ? Colors.black : Colors.grey.shade200,
        borderRadius: BorderRadius.circular(22),
      ),
      alignment: Alignment.center,
      child: DefaultTextStyle(
        style: TextStyle(color: active ? Colors.white : Colors.black),
        child: w,
      ),
    );
  }
}

class _ActiveView extends StatelessWidget {
  const _ActiveView();
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: const [
        ListTile(
            title: Text('Weekly Pushup Tournament'),
            subtitle: Text('Completed: 3822 of 10000')),
        ListTile(
            title: Text('Monthly Running Tournament'),
            subtitle: Text('Completed: 102 KM of 500 KM')),
      ],
    );
  }
}

class _ChallengesView extends StatelessWidget {
  const _ChallengesView();
  @override
  Widget build(BuildContext context) {
    final state = context.findAncestorStateOfType<_CommunityTabPageState>()!;
    final joined = state._joinedChallengeIds;

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        for (var id = 1; id <= 5; id++)
          Card(
            child: ListTile(
              leading: const Icon(Icons.flag_outlined),
              title: Text('Challenge #$id'),
              subtitle: const Text('7-day challenge'),
              trailing: TextButton(
                onPressed: () {
                  if (joined.contains(id)) {
                    joined.remove(id);
                  } else {
                    joined.add(id);
                  }
                  state.setState(() {});
                },
                child: Text(joined.contains(id) ? 'Leave' : 'Join'),
              ),
            ),
          ),
      ],
    );
  }
}


class _GroupsView extends StatelessWidget {
  const _GroupsView();
  @override
  Widget build(BuildContext context) {
    final state = context.findAncestorStateOfType<_CommunityTabPageState>();
    final premium = state?.widget.isPremium ?? false;
    final joined = state!._joinedGroupIds;

    Widget list = ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Align(
          alignment: Alignment.centerRight,
          child: FilledButton.icon(
            onPressed: premium ? () {} : null,
            icon: const Icon(Icons.add),
            label: const Text('Create group'),
          ),
        ),
        const SizedBox(height: 8),
        for (var id = 1; id <= 5; id++)
          Card(
            child: ListTile(
              leading: const Icon(Icons.group_outlined),
              title: Text('Group #$id'),
              subtitle: const Text('Social fitness group'),
              trailing: TextButton(
                onPressed: premium
                    ? () {
                  if (joined.contains(id)) {
                    joined.remove(id);
                  } else {
                    joined.add(id);
                  }
                  state.setState(() {});
                }
                    : null,
                child: Text(joined.contains(id) ? 'Leave' : 'Join'),
              ),
            ),
          ),
      ],
    );

    return Stack(
      children: [
        list,
        if (!premium)
          Positioned.fill(
            child: IgnorePointer(
              ignoring: false,
              child: Container(
                alignment: Alignment.center,
                color: Colors.white.withOpacity(0.70),
                child: const PremiumWall(
                  title: 'Premium Feature',
                  message: 'Create and join groups with Premium',
                ),
              ),
            ),
          ),
      ],
    );
  }
}


import 'package:flutter/material.dart';

class AppTheme {
  static const Color purpleLight = Color(0xFFE9E3FF); // light purple for tiles
  static const Color purple      = Color(0xFF6C63FF);
  static const Color dark        = Colors.black;

  static ThemeData theme() {
    final scheme = ColorScheme.fromSeed(seedColor: dark);
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme.copyWith(primary: dark, secondary: purple),

      // Black header like your mock
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
      ),

      scaffoldBackgroundColor: Colors.white,

      // Keep CardTheme simple for broad SDK compatibility
      cardTheme: const CardThemeData(
        elevation: 0,
        clipBehavior: Clip.antiAlias,
      ),


      // Basic Chip theme (older SDK-safe)
      chipTheme: ChipThemeData(
        backgroundColor: purpleLight,
        selectedColor: purpleLight,
        disabledColor: const Color(0xFFE0E0E0),
        secondarySelectedColor: purpleLight,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
        labelStyle: const TextStyle(color: Colors.black),
        secondaryLabelStyle: const TextStyle(color: Colors.black),
        brightness: Brightness.light,
        shape: const StadiumBorder(),
      ),
    );
  }
}
